import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowRight, Bell, BrainCircuit, CalendarDays, ChartNoAxesCombined, CheckCheck, CheckCircle2, ChevronDown, ChevronRight, ClipboardList, Database, FileText, Grid2X2, Headphones, House, Layers3, Menu, Moon, Network, NotebookPen, NotebookTabs, PanelRightOpen, RefreshCw, Search, Settings, ShieldAlert, ShieldCheck, ShieldPlus, Sun, UserRound, Waypoints, X, type LucideIcon } from 'lucide-react';
import { assetRisks, initialAssets, isAssetArray, securityControls, vulnerabilities, type Asset } from './data';
import AssetPanel, { type AssetAction, type AssetViewRequest } from './components/AssetPanel';
import { RiskBadge } from './components/AssetTable';
import DashboardOverview from './components/DashboardOverview';
import Dialogs, { type DialogState, type Report } from './components/Dialogs';
import { AssetExposureView, BusinessUnitsView, CategoryAnalysisView, ModuleView, ReportsView, type PlanItem } from './components/WorkspaceViews';
import useStoredState from './hooks/useStoredState';

interface SearchEntry {
  id: string;
  kind: 'asset' | 'risk' | 'vulnerability' | 'control';
  name: string;
  detail: string;
  level?: string;
  asset?: Asset;
}

const navigation: { title: string; items: { label: string; icon: LucideIcon; badge?: string }[] }[] = [
  { title: 'COMMAND CENTER', items: [{ label: 'Dashboard', icon: House }, { label: 'Assets', icon: Database }, { label: 'Vulnerabilities', icon: ShieldAlert, badge: '1.2K' }, { label: 'Threat Intelligence', icon: BrainCircuit }, { label: 'Security Controls', icon: ShieldPlus }] },
  { title: 'QUANTIFY', items: [{ label: 'Risk Analysis', icon: ChartNoAxesCombined }, { label: 'Financial Exposure', icon: NotebookTabs }] },
  { title: 'DECIDE', items: [{ label: 'Optimization', icon: NotebookPen }, { label: 'Recommendations', icon: Network }, { label: 'What-If Scenarios', icon: UserRound }] },
  { title: 'GOVERN', items: [{ label: 'Reports', icon: FileText }, { label: 'Compliance', icon: Layers3 }, { label: 'Audit Log', icon: ClipboardList }] },
  { title: 'SYSTEM', items: [{ label: 'Integrations', icon: Waypoints }, { label: 'Settings', icon: Settings }] },
];

const dashboardTabs = ['Overview', 'Asset Exposure', 'Business Units', 'Category Analysis', 'Scenario Analysis', 'Reports'];
const descriptions: Record<string, string> = {
  'Financial Exposure': 'Translate cyber risk into business impact. Make data-driven investment decisions.',
  Dashboard: 'Your command center for cyber risk, business impact, and resilience.',
  Assets: 'Discover, assess, and protect the assets that power your business.',
  Vulnerabilities: 'Prioritize security weaknesses by their potential business impact.',
  'Threat Intelligence': 'Turn emerging threat signals into actionable risk intelligence.',
  'Security Controls': 'Strengthen your defenses with measurable security control coverage.',
  'Risk Analysis': 'Understand your risk landscape. Focus on what matters most.',
  Optimization: 'Build a security investment plan that delivers measurable business value.',
  Recommendations: 'Take the next best action to reduce financial exposure.',
  'What-If Scenarios': 'Model security investments and explore a more resilient future.',
  Reports: 'Bring financial clarity to your security conversations.',
  Compliance: 'Connect security controls to your regulatory obligations.',
  'Audit Log': 'A transparent record of activity across your risk workspace.',
  Integrations: 'Connect your security ecosystem to a unified view of risk.',
  Settings: 'Make CyberRiskIQ work for your organization.',
};

function Brand({ onClick }: { onClick: () => void }) {
  return <button className="brand" onClick={onClick} aria-label="CyberRiskIQ home"><svg className="brand-mark" viewBox="0 0 45 50" aria-hidden="true"><defs><linearGradient id="brand-shield" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#009cff" /><stop offset="1" stopColor="#0056e8" /></linearGradient></defs><path d="M22.5 3C16 8 10 9 4 10c-1 18 6 29 18.5 37C35 39 42 28 41 10c-6-1-12-2-18.5-7Z" fill="#00121f" stroke="url(#brand-shield)" strokeWidth="4" /><path d="M22.5 13c-3.5 5-6.5 7-11 8 2 8 6 12 11 17 5-5 9-9 11-17-4.5-1-7.5-3-11-8Z" fill="url(#brand-shield)" /><path d="M22.5 13v25C18 33 14 29 12 21c4-1 7-4 10.5-8Z" fill="#0a73ff" /></svg><span><span className="brand-name">CyberRisk<span>IQ</span></span><span className="brand-tagline">From Risk to Resilience</span></span></button>;
}

export default function App() {
  const [assets, setAssets] = useStoredState('cyberriskiq-assets-v1', initialAssets, isAssetArray);
  const [section, setSection] = useState('Financial Exposure');
  const [activeTab, setActiveTab] = useState('Overview');
  const [selectedAssetId, setSelectedAssetId] = useState(1);
  const [panelRequest, setPanelRequest] = useState<AssetViewRequest>({ tab: 'Overview', id: 0 });
  const [detailOpen, setDetailOpen] = useState(() => window.innerWidth >= 1180);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [period, setPeriod] = useState('Last 12 Months');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [dialog, setDialog] = useState<DialogState | null>(null);
  const [popover, setPopover] = useState<'notifications' | 'apps' | 'profile' | null>(null);
  const [search, setSearch] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [unread, setUnread] = useState([1, 2, 3]);
  const [syncing, setSyncing] = useState(false);
  const [syncedAt, setSyncedAt] = useState('just now');
  const [unitFilter, setUnitFilter] = useState('All business units');
  const [category, setCategory] = useState('Data Breach');
  const [plan, setPlan] = useStoredState<PlanItem[]>('cyberriskiq-plan-v1', [], (value) => Array.isArray(value) && value.every((item) => item && typeof item.assetId === 'number' && typeof item.reduction === 'number' && typeof item.investment === 'number'));
  const [toast, setToast] = useState<string | null>(null);
  const [reports, setReports] = useStoredState<Report[]>('cyberriskiq-reports-v1', [
    { id: 1, name: 'Monthly Financial Exposure', date: 'Dec 31, 2025', format: 'CSV', assets: initialAssets },
    { id: 2, name: 'Critical Asset Risk Summary', date: 'Dec 24, 2025', format: 'CSV', assets: initialAssets.filter((asset) => asset.level === 'Critical') },
  ], (value) => Array.isArray(value) && value.every((report) => report && typeof report.id === 'number' && typeof report.name === 'string' && typeof report.format === 'string' && isAssetArray(report.assets)));
  const searchRef = useRef<HTMLInputElement>(null);
  const headerRef = useRef<HTMLElement>(null);
  const syncTimeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const selectedAsset = assets.find((asset) => asset.id === selectedAssetId) || assets[0];
  const notify = useCallback((message: string) => setToast(message), []);
  const closeDialog = useCallback(() => setDialog(null), []);
  const baseline = initialAssets.reduce((sum, asset) => sum + asset.ale, 0);
  const adjustedTotal = 4.8 + assets.reduce((sum, asset) => sum + asset.ale, 0) - baseline;
  const periodFactor = period === 'Last 6 Months' ? 0.94 : period === 'Last 3 Months' ? 0.89 : period === 'Year to Date' ? 0.97 : 1;
  const factor = Math.max(0.05, adjustedTotal / 4.8) * periodFactor;
  const supportsDetail = !['Settings', 'Integrations', 'Compliance', 'Audit Log'].includes(section);
  const displayDetail = detailOpen && supportsDetail;
  const searchEntries: SearchEntry[] = [
    ...assets.map((asset) => ({ id: `asset-${asset.id}`, kind: 'asset' as const, name: asset.name, detail: `${asset.unit} / ${asset.type}`, level: asset.level, asset })),
    ...assetRisks.map((risk, index) => ({ id: `risk-${index}`, kind: 'risk' as const, name: risk.name, detail: `Risk / ${risk.category}`, level: risk.severity })),
    ...vulnerabilities.map((item) => ({ id: item.id, kind: 'vulnerability' as const, name: item.name, detail: `Vulnerability / ${item.id}`, level: item.severity })),
    ...securityControls.map((control, index) => ({ id: `control-${index}`, kind: 'control' as const, name: control.name, detail: `Control / ${control.detail}` })),
  ];
  const query = search.trim().toLowerCase();
  const results = searchEntries.filter((entry) => query ? `${entry.name} ${entry.detail} ${entry.level || ''}`.toLowerCase().includes(query) : entry.kind === 'asset').slice(0, 6);

  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); searchRef.current?.focus(); setSearchOpen(true); }
      if (event.key === 'Escape') { setSearchOpen(false); setPopover(null); setSidebarOpen(false); }
    }
    function outsideClick(event: MouseEvent) {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) { setSearchOpen(false); setPopover(null); }
    }
    document.addEventListener('keydown', handleKey);
    document.addEventListener('mousedown', outsideClick);
    return () => { document.removeEventListener('keydown', handleKey); document.removeEventListener('mousedown', outsideClick); if (syncTimeout.current) clearTimeout(syncTimeout.current); };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    document.title = `${section} | CyberRiskIQ`;
  }, [section]);

  function navigate(nextSection: string) {
    setSection(nextSection);
    setSidebarOpen(false);
    setPopover(null);
    setSearchOpen(false);
    if (nextSection === 'Financial Exposure') setActiveTab('Overview');
  }

  function selectAsset(asset: Asset) {
    setSelectedAssetId(asset.id);
    setDetailOpen(true);
    setPanelRequest({ tab: 'Overview', id: Date.now() });
  }

  function searchSelect(asset: Asset) {
    selectAsset(asset);
    setSection('Financial Exposure');
    setActiveTab('Overview');
    setSearchOpen(false);
    setSearch('');
    searchRef.current?.blur();
  }

  function openSearchResult(entry: SearchEntry) {
    if (entry.asset) {
      searchSelect(entry.asset);
      return;
    }
    setSelectedAssetId(1);
    setDetailOpen(true);
    setSection('Financial Exposure');
    setActiveTab('Overview');
    setPanelRequest({ tab: entry.kind === 'risk' ? 'Risks' : entry.kind === 'vulnerability' ? 'Vulnerabilities' : 'Controls', item: entry.name, id: Date.now() });
    setSearchOpen(false);
    setSearch('');
    searchRef.current?.blur();
  }

  function handleAssetAction(action: AssetAction, asset: Asset) {
    setDialog({ kind: action, asset });
  }

  function togglePlan(asset: Asset) {
    const exists = plan.some((item) => item.assetId === asset.id);
    setPlan((current) => exists ? current.filter((item) => item.assetId !== asset.id) : [...current, { assetId: asset.id, reduction: 35, investment: 0.35 }]);
    notify(exists ? `${asset.name} removed from the optimization plan.` : `${asset.name} added to the optimization plan.`);
  }

  function saveScenario(asset: Asset, reduction: number, investment: number) {
    setPlan((current) => [...current.filter((item) => item.assetId !== asset.id), { assetId: asset.id, reduction, investment }]);
    notify(`Scenario for ${asset.name} saved to your optimization plan.`);
  }

  function syncData() {
    if (syncing) return;
    setSyncing(true);
    syncTimeout.current = setTimeout(() => {
      try {
        const stored = localStorage.getItem('cyberriskiq-assets-v1');
        const saved: unknown = stored ? JSON.parse(stored) : null;
        if (isAssetArray(saved)) setAssets(saved);
      } catch {
        // If storage is blocked, the current in-memory portfolio remains authoritative.
      }
      setSyncing(false);
      setSyncedAt(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
      notify('Portfolio refreshed from your saved workspace data.');
    }, 900);
  }

  const exportReport = () => setDialog({ kind: 'report' });
  const overview = <DashboardOverview assets={assets} factor={factor} period={period} onAsset={selectAsset} onUnit={(unit) => { setUnitFilter(unit); setSection('Financial Exposure'); setActiveTab('Asset Exposure'); }} onCategory={(name) => { setCategory(name); setSection('Financial Exposure'); setActiveTab('Category Analysis'); }} onMetric={(title, description) => setDialog({ kind: 'metric', title, description })} />;
  const reportsView = <ReportsView reports={reports} onCreate={exportReport} onDelete={(id) => { setReports((current) => current.filter((report) => report.id !== id)); notify('Report removed from your workspace.'); }} notify={notify} />;
  const assetView = <AssetExposureView assets={assets} onAsset={selectAsset} unitFilter={unitFilter} onUnitFilter={setUnitFilter} onExport={exportReport} factor={factor} period={period} />;
  const renderModule = (module: string) => <ModuleView section={module} assets={assets} selectedAsset={selectedAsset} onAsset={selectAsset} plan={plan} onRemovePlan={(id) => { setPlan((current) => current.filter((item) => item.assetId !== id)); notify('Investment removed from your plan.'); }} onScenario={(asset) => setDialog({ kind: 'scenario', asset })} onSaveScenario={saveScenario} notify={notify} />;

  function renderContent() {
    if (section === 'Dashboard') return overview;
    if (section === 'Assets') return assetView;
    if (section === 'Reports') return reportsView;
    if (section !== 'Financial Exposure') return renderModule(section);
    switch (activeTab) {
      case 'Asset Exposure': return assetView;
      case 'Business Units': return <BusinessUnitsView assets={assets} onAsset={selectAsset} factor={factor} />;
      case 'Category Analysis': return <CategoryAnalysisView initialCategory={category} factor={factor} />;
      case 'Scenario Analysis': return renderModule('What-If Scenarios');
      case 'Reports': return reportsView;
      default: return overview;
    }
  }

  return (
    <div className={`app-shell theme-${theme}`}>
      {sidebarOpen && <button className="sidebar-scrim" aria-label="Close navigation" onClick={() => setSidebarOpen(false)} />}
      <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-container"><Brand onClick={() => navigate('Financial Exposure')} /><button className="icon-button mobile-sidebar-close" aria-label="Close navigation" onClick={() => setSidebarOpen(false)}><X size={19} /></button></div>
        <nav className="main-navigation" aria-label="Main navigation">{navigation.map((group) => <div className="nav-group" key={group.title}><h2>{group.title}</h2>{group.items.map((item) => <button key={item.label} className={`nav-item ${section === item.label ? 'active' : ''}`} onClick={() => navigate(item.label)} aria-current={section === item.label ? 'page' : undefined}><item.icon size={20} strokeWidth={1.6} /><span>{item.label}</span>{item.badge && <b className="nav-alert-badge">{item.badge}</b>}{item.label === 'Optimization' && plan.length > 0 && <b className="plan-count">{plan.length}</b>}</button>)}</div>)}</nav>
        <div className="enterprise-promo"><div><Headphones size={33} strokeWidth={1.35} /><div><h3>Upgrade to Enterprise</h3><p>Unlock advanced analytics<br />and custom integrations.</p></div></div><button className="outline-button" onClick={() => setDialog({ kind: 'enterprise' })}>Learn More<ArrowRight size={14} /></button></div>
      </aside>

      <div className="workspace">
        <div className="masthead-art" aria-hidden="true" />
        <header className="topbar" ref={headerRef}>
          <button className="icon-button mobile-menu-button" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu size={21} /></button>
          <div className={`global-search ${searchOpen ? 'search-active' : ''}`}>
            <Search size={19} strokeWidth={1.5} />
            <input ref={searchRef} aria-label="Search assets, vulnerabilities, risks, and controls" placeholder="Search assets, vulnerabilities, risks, controls..." value={search} onChange={(event) => { setSearch(event.target.value); setSearchOpen(true); }} onFocus={() => { setSearchOpen(true); setPopover(null); }} onKeyDown={(event) => { if (event.key === 'Enter' && results[0]) openSearchResult(results[0]); }} />
            <kbd>Ctrl + K</kbd>
            {searchOpen && <div className="search-results topbar-popover"><div className="popover-label">{search ? 'SEARCH RESULTS' : 'QUICK ACCESS'}</div>{results.map((entry) => <button key={entry.id} onClick={() => openSearchResult(entry)}>{entry.kind === 'asset' ? <Database size={18} /> : entry.kind === 'risk' ? <BrainCircuit size={18} /> : entry.kind === 'vulnerability' ? <ShieldAlert size={18} /> : <ShieldCheck size={18} />}<span><strong>{entry.name}</strong><small>{entry.detail}</small></span>{entry.level && <RiskBadge level={entry.level} />}<ChevronRight size={14} /></button>)}{results.length === 0 && <div className="search-empty">No results found for &quot;{search}&quot;.<br /><small>Try an asset, vulnerability, risk, or security control.</small></div>}<div className="search-hint"><kbd>Enter</kbd> to open the first result <span><kbd>Esc</kbd> to close</span></div></div>}
          </div>
          <div className="topbar-actions">
            <button className={`live-sync ${syncing ? 'is-syncing' : ''}`} onClick={syncData} disabled={syncing} title={`Last synchronized: ${syncedAt}`}>{syncing ? <RefreshCw size={13} className="spin" /> : <i />}<span>{syncing ? 'Syncing Data...' : 'Live Data Sync'}</span></button>
            <div className="topbar-action-wrap"><button className={`icon-button notifications-button ${popover === 'notifications' ? 'selected' : ''}`} aria-label={`Notifications, ${unread.length} unread`} aria-expanded={popover === 'notifications'} onClick={() => { setPopover(popover === 'notifications' ? null : 'notifications'); setSearchOpen(false); }}><Bell size={21} strokeWidth={1.5} />{unread.length > 0 && <span className="notification-count">{unread.length}</span>}</button>{popover === 'notifications' && <div className="topbar-popover notifications-popover"><div className="popover-heading"><h3>Notifications</h3><button className="icon-button" onClick={() => { setUnread([]); notify('All notifications marked as read.'); }} title="Mark all as read"><CheckCheck size={17} /></button></div>{[{ id: 1, title: 'Critical payment gateway risk', text: 'Review the financial impact of your highest-risk asset.', time: '5 min ago', asset: 1 }, { id: 2, title: 'Finance assessment updated', text: 'New financial inputs are ready for your review.', time: '24 min ago', asset: 2 }, { id: 3, title: 'Exposure report is ready', text: 'Your monthly financial exposure summary is available.', time: '1 hour ago', asset: 0 }].map((notification) => <button className={`notification-item ${unread.includes(notification.id) ? 'unread' : ''}`} key={notification.id} onClick={() => { setUnread((current) => current.filter((id) => id !== notification.id)); setPopover(null); if (notification.asset) searchSelect(assets.find((asset) => asset.id === notification.asset)!); else { setSection('Financial Exposure'); setActiveTab('Reports'); } }}><span className="notification-indicator" /><span><strong>{notification.title}</strong><p>{notification.text}</p><small>{notification.time}</small></span></button>)}</div>}</div>
            <span className="topbar-divider" />
            <div className="topbar-action-wrap"><button className="icon-button apps-button" aria-label="Open workspace switcher" aria-expanded={popover === 'apps'} onClick={() => { setPopover(popover === 'apps' ? null : 'apps'); setSearchOpen(false); }}><Grid2X2 size={21} strokeWidth={1.5} /></button>{popover === 'apps' && <div className="topbar-popover apps-popover"><div className="popover-label">YOUR WORKSPACES</div>{[{ title: 'Risk Workspace', text: 'Quantify and manage cyber risk', section: 'Financial Exposure', icon: ShieldCheck }, { title: 'Executive View', text: 'Your organization at a glance', section: 'Dashboard', icon: ChartNoAxesCombined }, { title: 'Audit Workspace', text: 'Compliance and activity records', section: 'Compliance', icon: ClipboardList }].map((item) => <button key={item.title} onClick={() => navigate(item.section)}><item.icon size={22} /><span><strong>{item.title}</strong><small>{item.text}</small></span><ChevronRight size={14} /></button>)}</div>}</div>
            <span className="topbar-divider profile-divider" />
            <div className="topbar-action-wrap profile-wrap"><button className="profile-button" onClick={() => { setPopover(popover === 'profile' ? null : 'profile'); setSearchOpen(false); }} aria-label="Open Yash Galande profile menu" aria-expanded={popover === 'profile'}><span className="avatar">YG</span><span className="profile-copy"><strong>Yash Galande</strong><small>CISO</small></span></button>{popover === 'profile' && <div className="topbar-popover profile-popover"><div className="profile-menu-heading"><strong>Yash Galande</strong><span>Workspace administrator</span></div><button onClick={() => { setDialog({ kind: 'profile' }); setPopover(null); }}><UserRound size={16} />Your Profile</button><button onClick={() => navigate('Settings')}><Settings size={16} />Workspace Settings</button><div className="profile-security"><ShieldCheck size={14} />Secure session</div></div>}</div>
            <button className="icon-button theme-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}>{theme === 'dark' ? <Sun size={25} strokeWidth={1.3} /> : <Moon size={23} strokeWidth={1.5} />}</button>
          </div>
        </header>

        <div className="page-heading"><div className="page-heading-copy"><div className="breadcrumbs"><button onClick={() => navigate('Dashboard')}>Home</button><ChevronRight size={12} /><span>{section}</span></div><h1>{section}</h1><p>{descriptions[section]}</p></div><div className="page-heading-tools"><p className="brand-motto">QUANTIFY TODAY<br />INVEST WISELY<br />A MORE RESILIENT TOMORROW.</p><label className="period-select"><CalendarDays size={17} /><select aria-label="Reporting period" value={period} onChange={(event) => setPeriod(event.target.value)}><option>Last 12 Months</option><option>Last 6 Months</option><option>Last 3 Months</option><option>Year to Date</option></select><ChevronDown size={13} /></label><button className="primary-button export-button" onClick={exportReport}><ArrowDownToLine size={15} />Export</button>{!displayDetail && supportsDetail && <button className="outline-button show-details-button" aria-label="Open asset details" onClick={() => setDetailOpen(true)}><PanelRightOpen size={17} /></button>}</div></div>

        <div className={`dashboard-layout ${displayDetail ? 'has-detail' : ''}`}>
          <main className={`dashboard-main ${section !== 'Financial Exposure' ? 'module-main' : ''}`}>
            {section === 'Financial Exposure' && <nav className="dashboard-tabs" role="tablist" aria-label="Financial exposure views">{dashboardTabs.map((tab, index) => <button id={`exposure-tab-${index}`} key={tab} role="tab" aria-selected={activeTab === tab} aria-controls="financial-view" tabIndex={activeTab === tab ? 0 : -1} className={activeTab === tab ? 'active' : ''} onClick={() => setActiveTab(tab)} onKeyDown={(event) => { if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return; event.preventDefault(); const next = (index + (event.key === 'ArrowRight' ? 1 : -1) + dashboardTabs.length) % dashboardTabs.length; setActiveTab(dashboardTabs[next]); document.getElementById(`exposure-tab-${next}`)?.focus(); }}>{tab}</button>)}</nav>}
            <div id="financial-view" role={section === 'Financial Exposure' ? 'tabpanel' : undefined} aria-labelledby={section === 'Financial Exposure' ? `exposure-tab-${dashboardTabs.indexOf(activeTab)}` : undefined} className={`main-view ${section === 'Financial Exposure' && activeTab === 'Overview' || section === 'Dashboard' ? 'is-overview' : ''}`} key={`${section}-${activeTab}`}>{renderContent()}</div>
          </main>
          {displayDetail && <AssetPanel asset={selectedAsset} onClose={() => setDetailOpen(false)} onAction={handleAssetAction} onPlan={togglePlan} inPlan={plan.some((item) => item.assetId === selectedAsset.id)} notify={notify} viewRequest={panelRequest} />}
        </div>
      </div>
      {dialog && <Dialogs dialog={dialog} assets={assets} onClose={closeDialog} onSaveAsset={(asset) => { setAssets((current) => current.map((item) => item.id === asset.id ? asset : item)); setDialog(null); notify(`Financial inputs updated for ${asset.name}.`); }} onSaveReport={(report) => { setReports((current) => [report, ...current]); setDialog(null); notify('Your report has been generated and downloaded.'); }} onSaveScenario={saveScenario} notify={notify} />}
      {toast && <div className="toast" role="status"><CheckCircle2 size={19} /><span>{toast}</span><button className="icon-button" onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={15} /></button></div>}
    </div>
  );
}
